package ir.property.types;

public enum PhoneType {
	mobile,
	home,
	work

}
