package ir.property.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import ir.property.entity.Property;
import ir.property.service.PropertyService;

@Controller
@RequestMapping("/property")
public class PropertyController {

	@Autowired
	private PropertyService propertyService;
	
	@GetMapping("/list")
	public String listPropertys(Model theModel) {
		List<Property> theProperties = propertyService.getProperties();
		theModel.addAttribute("properties", theProperties);
		return "list-properties";
	}
	
	@GetMapping("/showForm")
	public String showFormForAdd(Model theModel) {
		Property theProperty = new Property();
		theModel.addAttribute("property", theProperty);
		return "property-form";
	}
	
	@PostMapping("/saveProperty")
	public String saveProperty(@ModelAttribute("property") Property theProperty) {
		propertyService.saveProperty(theProperty);	
		return "redirect:/property/list";
	}
	
	@GetMapping("/updateForm")
	public String showFormForUpdate(@RequestParam("propertyId") int theId,
									Model theModel) {
		Property theProperty = propertyService.getProperty(theId);	
		theModel.addAttribute("property", theProperty);
		return "property-form";
	}
	
	@GetMapping("/delete")
	public String deleteProperty(@RequestParam("propertyId") int theId) {
		propertyService.deleteProperty(theId);
		return "redirect:/Property/list";
	}
}
