package ir.property.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import ir.property.dao.PropertyDAO;
import ir.property.entity.Property;

@Service
public class PropertyServiceImpl implements PropertyService {

	@Autowired
	private PropertyDAO PropertyDAO;
	
	@Override
	@Transactional
	public List<Property> getProperties() {
		return PropertyDAO.getProperties();
	}

	@Override
	@Transactional
	public void saveProperty(Property theProperty) {
		PropertyDAO.saveProperty(theProperty);
	}

	@Override
	@Transactional
	public Property getProperty(int theId) {
		return PropertyDAO.getProperty(theId);
	}

	@Override
	@Transactional
	public void deleteProperty(int theId) {
		PropertyDAO.deleteProperty(theId);
	}
}





