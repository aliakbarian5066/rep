package ir.property.service;

import java.util.List;

import ir.property.entity.Property;

public interface PropertyService {

	public List<Property> getProperties();

	public void saveProperty(Property theProperty);

	public Property getProperty(int theId);

	public void deleteProperty(int theId);
	
}
