package ir.property.entity;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OrderColumn;
import javax.persistence.Table;
/**
 * 
 *
 */
@Entity
@Table(name = "property")


public class Property{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="property_id")
    private int id;
    
    @Embedded
    @Column(name="address")
    private Address address;
    
    @OneToMany
    @OrderColumn(name = "user_id") 
    private Owner[] owners;
	
    public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Address getAddress() {
		return address;
	}
	
	public void setAddress(Address address) {
		this.address = address;
	}
	public Owner[] getOwners() {
		return owners;
	}
	public void setOwners(Owner[] owners) {
		this.owners = owners;
	}
   
}