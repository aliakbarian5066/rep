package ir.property.dao;

import java.util.List;

import ir.property.entity.Property;

public interface PropertyDAO {

	public List<Property> getProperties();

	public void saveProperty(Property theProperty);

	public Property getProperty(int theId);

	public void deleteProperty(int theId);
	
}
