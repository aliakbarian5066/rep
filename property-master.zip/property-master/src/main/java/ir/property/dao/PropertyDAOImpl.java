package ir.property.dao;

import java.util.List;

import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import ir.property.entity.Property;

@Repository
public class PropertyDAOImpl implements PropertyDAO {

	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public List<Property> getProperties() {
		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder cb = session.getCriteriaBuilder();
		CriteriaQuery<Property> cq = cb.createQuery(Property.class);
		Root<Property> root = cq.from(Property.class);
		cq.select(root);
		Query query = session.createQuery(cq);
		return query.getResultList();
	}

	@Override
	public void deleteProperty(int id) {
		Session session = sessionFactory.getCurrentSession();
		Property Property = session.byId(Property.class).load(id);
		session.delete(Property);
	}

	@Override
	public void saveProperty(Property theProperty) {
		Session currentSession = sessionFactory.getCurrentSession();
		currentSession.saveOrUpdate(theProperty);
	}

	@Override
	public Property getProperty(int theId) {
		Session currentSession = sessionFactory.getCurrentSession();
		Property theProperty = currentSession.get(Property.class, theId);
		return theProperty;
	}
}
